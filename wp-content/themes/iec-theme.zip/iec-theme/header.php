<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package base_theme
 */
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
?>
<!doctype html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <title>
        <?php wp_title( '-', true, 'right' ); ?>
    </title>
    <?php wp_head(); ?>

    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
</head>

<body class="">
    <div id="page" class="site-main d-flex flex-column min-vh-100">
        <header class="main-header">
            <nav class="navbar navbar-expand-lg fixed-top main-navigation" id="navigation-scroll">
                <div class="container container-nav">
                    <!-- Logo on the left -->
                    <div class="navbar-brand py-0">
                        <a class="logo-wrap" href="<?php echo get_home_url(); ?>">
                            <?php
                    $custom_logo_id = get_theme_mod('custom_logo');
                    $logo = wp_get_attachment_image_src($custom_logo_id, 'full');

                    if ($logo) {
                        echo '<img class="img-fluid site-logo" src="' . esc_url($logo[0]) . '" alt="tci-logo">';
                    } else {
                        echo 'TCI';
                    }
                    ?>
                        </a>
                    </div>

                    <!-- Offcanvas toggle button -->
                    <button class="navbar-toggler menu-button" type="button" data-bs-toggle="offcanvas"
                        data-bs-target="#mobileMenu" aria-controls="mobileMenu">
                        <span class="navbar-toggler-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                <path d="M3 4H21V6H3V4ZM9 11H21V13H9V11ZM3 18H21V20H3V18Z" fill="rgba(0,0,0,1)"></path>
                            </svg>
                        </span>
                    </button>

                    <!-- Offcanvas menu -->
                    <div class="offcanvas offcanvas-end " tabindex="-1" id="mobileMenu">
                        <div class="offcanvas-header">
                            <h5 class="offcanvas-title">
                                <a class="mb-logo-wrap" href="<?php echo get_home_url(); ?>">
                                    <?php
                            $custom_logo_id = get_theme_mod('custom_logo');
                            $logo = wp_get_attachment_image_src($custom_logo_id, 'full');

                            if ($logo) {
                                echo '<img class="img-fluid mb-menu-logo" src="' . esc_url($logo[0]) . '" alt="IEC-Logo">';
                            } else {
                                echo 'IEC';
                            }
                            ?>
                                </a>
                            </h5>
                            <button type="button" class="btn-close text-reset offcanvas-close-btn"
                                data-bs-dismiss="offcanvas" aria-label="Close"></button>
                        </div>
                        <div class="offcanvas-body ms-lg-auto navigation-wrapper">
                            <!-- The WordPress Menu goes here -->
                            <?php wp_nav_menu(array(
                        'theme_location'  => 'primary',
                        'container'       => 'main-header',
                        'container_class' => 'navbar',
                        'container_id'    => 'navbarSupportedContent',
                        'menu_class'      => 'navbar-nav ms-auto',
                        'fallback_cb'     => '',
                        'depth'           => 2, // 1 = no dropdowns, 2 = with dropdowns.
                        'walker'          => new WP_Bootstrap_Navwalker(),
                    )); ?>
                        </div>
                    </div>
                </div>
            </nav>
        </header>