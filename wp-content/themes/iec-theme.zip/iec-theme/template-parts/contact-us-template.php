<?php 
/** 
* Template Name: Contact Page
*
* @package base_theme
**/

get_header();

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
?>

<div class="page-content contact-page">

    <!-- hero section -->
    <section class="hero-section" style="background-color:<?php the_field('background_color'); ?>">
        <div class="row">
            <div class="col-12 col-md-5 col-lg-5 left">
                <div class="hero-text">
                    <h1 data-aos="fade-zoom-in" data-aos-duration="800">
                        <?php echo nl2br( esc_html( get_field('banner_title') ) ); ?></h1>
                    <p data-aos="fade-zoom-in" data-aos-duration="1000">
                        <?php echo nl2br( esc_html( get_field('banner_description') ) ); ?></p>
                </div>
            </div>
            <div class="col-12 col-md-7 col-lg-7 right">
                <?php 
                $image = get_field('banner_image');
                if( !empty( $image ) ): ?>
                <img class="bg-image img-fluid" src="<?php echo esc_url($image['url']); ?>"
                    alt="<?php echo esc_attr($image['title']); ?>" loading="lazy" decoding="async" role="img"
                    aria-label="image">
                <?php endif; ?>
            </div>
        </div>
    </section>

    <div class="container">
        <!-- page navigation -->
    <section class="location-section">
        <div class="locat">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#195d9a">
                <path
                    d="M20 20C20 20.5523 19.5523 21 19 21H5C4.44772 21 4 20.5523 4 20V11L1 11L11.3273 1.6115C11.7087 1.26475 12.2913 1.26475 12.6727 1.6115L23 11L20 11V20ZM11 13V19H13V13H11Z">
                </path>
            </svg>
            <p class="page-name1">
                <?php echo ( get_field('home_name') ); ?>
            </p>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                <path
                    d="M13.1717 12.0007L8.22192 7.05093L9.63614 5.63672L16.0001 12.0007L9.63614 18.3646L8.22192 16.9504L13.1717 12.0007Z">
                </path>
            </svg>
            <p class="page-name">
                <?php echo ( get_field('page_name') ); ?>
            </p>
        </div>
    </section>
    </div>

    <!-- form section -->
    <section class="form-section">
        <div class="row">
            <div class="col-12 col-md-6 col-lg-6 left">
                <div class="details">
                    <div class="contact-info">

                        <!-- Address -->
                        <h6 data-aos="fade-zoom-in" data-aos-duration="1000">
                            <?php echo nl2br( esc_html( get_field('info_address') ) ); ?></h5>
                            <p data-aos="fade-zoom-in" data-aos-duration="1000">
                                <?php echo nl2br( esc_html( get_field('address_description') ) ); ?></p>

                            <br>

                            <!-- Direct Line -->
                            <h6 data-aos="fade-zoom-in" data-aos-duration="1000">
                                <?php echo nl2br( esc_html( get_field('info_direct_line') ) ); ?></h6>
                            <p data-aos="fade-zoom-in" data-aos-duration="1000">
                                <a href="tel:<?php echo esc_attr( get_field('direct_line') ); ?>">
                                    <?php echo nl2br( esc_html( get_field('direct_line') ) ); ?>
                                </a>
                            </p>


                            <br>

                            <!-- Hotline -->
                            <h6 data-aos="fade-zoom-in" data-aos-duration="1000">
                                <?php echo nl2br( esc_html( get_field('info_hotline') ) ); ?></h6>
                            <p data-aos="fade-zoom-in" data-aos-duration="1000">
                                <a href="tel:<?php echo esc_html( get_field('hotline') ); ?>">
                                    <?php echo nl2br( esc_html( get_field('hotline') ) ); ?>
                                </a>
                            </p>


                            <br>

                            <!-- Email Address -->
                            <h6 data-aos="fade-zoom-in" data-aos-duration="1000">
                                <?php echo nl2br( esc_html( get_field('info_email') ) ); ?></h6>
                            <p data-aos="fade-zoom-in" data-aos-duration="1000">
                                <a href="mailto:<?php echo esc_html( get_field('email') ); ?>">
                                    <?php echo nl2br( esc_html( get_field('email') ) ); ?>
                                </a>
                            </p>


                            <br>

                            <!-- Social Media Section -->
                            <div class="social-media-container">
                                <?php if( have_rows('social_media_repeater') ): ?>
                                <?php while( have_rows('social_media_repeater') ): the_row(); ?>
                                <?php $platform = get_sub_field('platform'); ?>
                                <?php $image = get_sub_field('social_image'); ?>

                                <?php if( $image ): ?>
                                <a href="<?php echo get_sub_field('social_url'); ?>">
                                    <img class="bg-image img-fluid" width="25px" height="20px"
                                        src="<?php echo esc_url($image['url']); ?>"
                                        alt="<?php echo esc_attr($image['alt']); ?>" loading="lazy" decoding="async"
                                        role="img" aria-label="<?php echo esc_attr($platform); ?>">
                                </a>
                                <?php endif; ?>
                                <?php endwhile; ?>
                                <?php endif; ?>
                            </div>

                            <?php $image = get_field('desgin_image'); if( !empty( $image ) ): ?>
                            <img class="circle-img img-fluid" width="30%" src="<?php echo esc_url($image['url']); ?>"
                                alt="<?php echo esc_attr($image['title']); ?>" loading="lazy" decoding="async"
                                role="img" aria-label="image"><?php endif; ?>


                    </div>
                </div>
            </div>

            <!-- Consultancy Form -->
            <div class="col-12 col-md-6 col-lg-6 right">
                <div class="consultancy-form">
                    <?php echo apply_shortcodes( '[forminator_form id="339"]' ); ?>
                </div>
            </div>
        </div>
    </section>

    <!-- map-section -->
    <section class="map-section">

        <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3961.2134479745396!2d79.86087277373227!3d6.865005519103202!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ae25baf89d56f51%3A0x1f550bbb4841e767!2sInternational%20Education%20Consultancy!5e0!3m2!1sen!2slk!4v1710392589346!5m2!1sen!2slk"
            width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"
            referrerpolicy="no-referrer-when-downgrade"></iframe>


    </section>


</div>

<?php get_footer(); ?>