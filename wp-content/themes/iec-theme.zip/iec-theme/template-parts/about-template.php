<?php 
/** 
* Template Name: About Us Page
*
* @package base_theme
**/ 
get_header();
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
?>

<div class="page-content about-page">

    <!-- Hero Section -->
    <section class="hero-section" style="background-color:<?php the_field('background_color'); ?>">

        <div class="row g-0">
            <div class="col-12 col-md-5 col-lg-5 left">
                <div class="hero-text">
                    <h1 data-aos="fade-zoom-in" data-aos-duration="800">
                        <?php echo nl2br( esc_html( get_field('banner_title') ) ); ?>
                    </h1>
                    <p data-aos="fade-zoom-in" data-aos-duration="1000">
                        <?php echo nl2br( esc_html( get_field('banner_description') ) ); ?>
                    </p>
                </div>
            </div>
            <div class="col-12 col-md-7 col-lg-7 right">
                <?php 
            $image = get_field('banner_image');
            if( !empty( $image ) ): ?>
                <img class="bg-image img-fluid" src="<?php echo esc_url($image['url']); ?>"
                    alt="<?php echo esc_attr($image['title']); ?>" loading="lazy" decoding="async" role="img"
                    aria-label="image">
                <?php endif; ?>
            </div>
        </div>
    </section>
    <!-- page nav -->
    <section class="location-section">
        <div class="container">
            <div class="locat">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#195d9a">
                    <path
                        d="M20 20C20 20.5523 19.5523 21 19 21H5C4.44772 21 4 20.5523 4 20V11L1 11L11.3273 1.6115C11.7087 1.26475 12.2913 1.26475 12.6727 1.6115L23 11L20 11V20ZM11 13V19H13V13H11Z">
                    </path>
                </svg>
                <p class="page-name1">
                    <?php echo ( get_field('home_name') ); ?>
                </p>
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                    <path
                        d="M13.1717 12.0007L8.22192 7.05093L9.63614 5.63672L16.0001 12.0007L9.63614 18.3646L8.22192 16.9504L13.1717 12.0007Z">
                    </path>
                </svg>
                <p class="page-name">
                    <?php echo ( get_field('about_name') ); ?>
                </p>



            </div>
        </div>
    </section>

    <!-- first Content -->
    <section class="aboutus-section">
        <div class="container">
            <div class="aboutus">
                <div class="row g-0">
                    <div class="col-12 col-md-7 col-lg-7">
                        <div class="left">
                            <div class="first-title">
                                <h2 class="title">
                                    <?php echo ( get_field('first_content_title') ); ?>
                                </h2>
                            </div>
                            <div class="paragraph">
                                <p class="about-paragraph">
                                    <?php echo ( get_field('about_paragraph') ); ?>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-5 col-lg-5">
                        <div class="right-image">
                            <img src=" <?php echo ( get_field('about_image') ); ?>" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>


    <!-- Funder Content -->
    <section class="founder-section">
        <div class="container">
            <div class="funder">
                <div class="funder-title">
                    <h2 class="title">
                        <?php echo ( get_field('funder_title') ); ?>
                    </h2>
                </div>
                <!-- Desktop -->
                <div class="row g-0">
                    <div class="col-12 col-md-10 col-lg-10 order-2 order-md-2">

                        <div class="paragraph-funder">
                            <p class="paragraph">
                                <?php echo ( get_field('funder_first_paragraph') ); ?>
                        </div>
                    </div>
                    <div class="col-12 col-md-2 col-lg-2 order-1 order-md-2">
                        <div class="funder-image">
                            <img src="<?php echo ( get_field('funder_first_image') ); ?>" alt="" class="image">
                        </div>
                        <div class="funder-name">
                            <h4 class="name">
                                <?php echo ( get_field('first_funder_name') ); ?>
                            </h4>
                            <p class="position">
                                <?php echo ( get_field('first_funder_position') ); ?>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="row g-0">
                    <div class="col-12 col-md-2 col-lg-2">
                        <div class="funder-image">
                            <img src="<?php echo ( get_field('funder_second_image') ); ?>" alt="" class="image">
                        </div>
                        <div class="funder-name">
                            <h4 class="name">
                                <?php echo ( get_field('second_funder_name') ); ?>
                            </h4>
                            <p class="position">
                                <?php echo ( get_field('second_funder_position') ); ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-12 col-md-10 col-lg-10">
                        <div class="paragraph-funder2">
                            <p class="paragraph2">
                                <?php echo ( get_field('funder_second_paragraph') ); ?>

                            </p>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>

    <!-- Meet The Team -->
    <section class="team-section">
        <div class="container">
            <div class="team">
                <div class="team-title">
                    <h2 class="title"><?php echo ( get_field('meet_the_team_title') ); ?> </h2>
                </div>

                <div class="team-card">

                    <?php if( have_rows('meet_the_team') ): ?>
                    <?php while( have_rows('meet_the_team') ): the_row(); ?>
                    <div class="card-wrap">
                        <div class="card">
                            <h5 class="title"><?php the_sub_field('member_name'); ?></h5>
                            <h6 class="position"><?php the_sub_field('member_possition'); ?></h6>
                            <p class="description"><?php the_sub_field('member_description'); ?></p>
                        </div>
                    </div>
                    <?php endwhile; ?>
                    <?php endif; ?>
                </div>

            </div>
        </div>
    </section>

    <!-- News -->
    <section class="news-section">
        <div class="container">
            <div class="news">
                <div class="news-title">
                    <h2 class="title"><?php echo get_field('news_title'); ?></h2>
                </div>
                <div class="news-description">
                    <p class="description"><?php echo get_field('news_description'); ?></p>
                </div>
                <div class="news-slider">
                    <div class="owl-slider">
                        <div id="carousel1" class="owl-carousel">
                            <?php
                            // Query all news posts
                            $args = array(
                                'post_type' => 'news',
                                'posts_per_page' => -1,
                            );
                            $news_query = new WP_Query($args);

                            // Loop through news posts and display them
                            if ($news_query->have_posts()) {
                                while ($news_query->have_posts()) {
                                    $news_query->the_post();
                                    $post_id = get_the_ID();
                                    ?>
                            <div class="item" data-news-id="<?php echo $post_id; ?>"
                                data-image-src="<?php echo get_field('news_image'); ?>"
                                data-description="<?php echo get_field('news_description'); ?>">
                                <a class="popup-trigger" href="#">
                                    <img src="<?php echo get_field('news_image'); ?>" alt="1000X1000">
                                </a>
                                <p><?php echo get_field('news_description'); ?></p>
                            </div>
                            <?php
                                }
                            } else {
                                echo 'No news found.';
                            }

                            // Reset the post data
                            wp_reset_postdata();
                        ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Popup Container -->
    <div id="popup" class="popup-container">
        <div class="popup-content">
            <span class="close">&times;</span>
            <img id="popup-image" src="" alt="Popup Image">
            <p id="popup-description"></p>
        </div>
    </div>

    <!-- Event -->
    <section class="event-section">
        <div class="container">
            <div class="event">
                <div class="event-title">
                    <h2 class="title">
                        <?php echo get_field('event_title'); ?>
                    </h2>
                </div>
                <div class="event-slider">
                    <div class="owl-slider">
                        <div id="carousel2" class="owl-carousel">
                            <?php
                        // Query all products
                        $args = array(
                            'post_type'      => 'events',
                            'posts_per_page' => -1,
                        );
                        $blogs = new WP_Query($args);

                        // Loop through products and display them
                        if ($blogs->have_posts()) {
                            while ($blogs->have_posts()) {
                                $blogs->the_post();?>
                            <div class="item">
                                <img src="<?php echo get_field('event_image'); ?>" alt="1000X1000">
                                <div class="calander">
                                    <img src="<?php echo get_field('calender'); ?>" alt="" class="icon">
                                    <p class="time"><?php echo get_field('event_time'); ?></p>
                                </div>
                                <div class="user">
                                    <img src="<?php echo get_field('users'); ?>" alt="" class="icon">
                                    <p class="count"><?php echo get_field('evint_count'); ?></p>
                                </div>
                                <div class="button">
                                    <a href="#">
                                        <img src="<?php echo get_field('event_register_url'); ?>" alt="" class="reg">
                                    </a>
                                </div>
                            </div>
                            <?php }
                        } else {
                            echo 'No products found.';
                        }
                        // Reset the post data
                        wp_reset_postdata();
                        ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Gallery -->
    <section class="gallery-section">
        <div class="container">
            <div class="gallery">
                <div class="gallery-title">
                    <!-- Title -->
                    <h2 class="title"><?php echo get_field('gallery_title'); ?></h2>
                </div>
                <div class="gallery-slider">
                    <div class="owl-slider">
                        <div id="carousel3" class="owl-carousel">
                            <?php
                        // Query all products
                        $args = array(
                            'post_type'      => 'gallery_post', // Assuming 'gallery_post' is your custom post type
                            'posts_per_page' => -1, // Retrieve all posts
                        );
                        $blogs = new WP_Query($args);

                        // Loop through products
                        if ($blogs->have_posts()) {
                            while ($blogs->have_posts()) {
                                $blogs->the_post();
                                // Get the repeater field 'Gallery Images'
                                $gallery_images = get_field('gallery_images');
                                // Check if there are images in the repeater field
                                if ($gallery_images) {
                                    // Get the URL of the first image
                                    $first_image_url = $gallery_images[0]['gallery_image'];
                                    // Get the gallery description
                                    $gallery_description = get_field('gallery_description');
                                    ?>
                            <div class="item gallery-item">
                                <!-- Open fancybox on click -->
                                <a class="fancybox" href="#popup-<?php echo get_the_ID(); ?>" data-fancybox="gallery"
                                    data-caption="<?php echo $gallery_description; ?>">
                                    <!-- Display the image -->
                                    <img src="<?php echo $first_image_url; ?>" alt="1000X1000">
                                </a>
                                <!-- Display the description -->
                                <p class="gallery-description"><?php echo $gallery_description; ?></p>
                            </div>
                            <?php }
                            }
                        } else {
                            echo 'No products found.';
                        }
                        // Reset the post data
                        wp_reset_postdata();
                        ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php
// Query all products again to generate popups outside of the loop
$blogs = new WP_Query($args);

// Loop through products to generate popups
if ($blogs->have_posts()) {
    while ($blogs->have_posts()) {
        $blogs->the_post();
        // Get the repeater field 'Gallery Images'
        $gallery_images = get_field('gallery_images');
        // Check if there are images in the repeater field
        if ($gallery_images) {
            ?>
    <!-- Popup for this post -->
    <div id="popup-<?php echo get_the_ID(); ?>" class="popup">
        <div class="popup-content">
            <!-- Close button -->
            <span class="close">&times;</span>
            <!-- Popup images container -->
            <div class="popup-images">
                <?php
                        // Loop through each image in the repeater field
                        foreach ($gallery_images as $image) {
                            // Get the URL of the image
                            $image_url = $image['gallery_image'];
                            ?>
                <!-- Display the image -->
                <a href="<?php echo $image_url; ?>" data-fancybox="gallery">
                    <img src="<?php echo $image_url; ?>" alt="1000X1000">
                </a>
                <?php } ?>
            </div>
        </div>
    </div>
    <?php }
    }
}
?>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.css" />

</div>

<?php
get_footer();