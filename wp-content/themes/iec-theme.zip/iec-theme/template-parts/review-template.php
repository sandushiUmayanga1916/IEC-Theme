<?php 
/** 
* Template Name: Review Page
*
* @package base_theme
**/ 
get_header();
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
?>

<div class="page-content review-page">

    <!-- Hero Section -->
    <section class="hero-section" style="background-color:<?php the_field('background_color'); ?>">
        <div class="row g-0">
            <div class="col-12 col-md-5 col-lg-5 left">
                <div class="hero-text">
                    <div class="container">
                        <h1 data-aos="fade-zoom-in" data-aos-duration="800">
                            <?php echo nl2br( esc_html( get_field('hero_title') ) ); ?></h1>
                        <p data-aos="fade-zoom-in" data-aos-duration="1000">
                            <?php echo nl2br( esc_html( get_field('hero_description') ) ); ?></p>
                        <a href="<?php echo get_field('talk_to_us'); ?>"> <img data-aos="fade-zoom-in"
                                data-aos-duration="1200" class="btn-image img-fluid" width="130" height="100%"
                                src="<?php echo get_home_url() ?>/wp-content/uploads/2024/02/button.png"
                                alt="<?php echo esc_attr($image['title']); ?>" loading="lazy" decoding="async"
                                role="img" aria-label="image"></a>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-7 col-lg-7 right">
                <?php 
                $image = get_field('hero_image');
                if( !empty( $image ) ): ?>
                <img class="bg-image img-fluid" src="<?php echo esc_url($image['url']); ?>"
                    alt="<?php echo esc_attr($image['title']); ?>" loading="lazy" decoding="async" role="img"
                    aria-label="image">
                <?php endif; ?>
            </div>
        </div>
    </section>

    <div class="container">
        <!-- page nav -->
        <section class="location-section">
            <div class="locat">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#195d9a">
                    <path
                        d="M20 20C20 20.5523 19.5523 21 19 21H5C4.44772 21 4 20.5523 4 20V11L1 11L11.3273 1.6115C11.7087 1.26475 12.2913 1.26475 12.6727 1.6115L23 11L20 11V20ZM11 13V19H13V13H11Z">
                    </path>
                </svg>
                <p class="page-name1">
                    <?php echo ( get_field('home_name') ); ?>
                </p>
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                    <path
                        d="M13.1717 12.0007L8.22192 7.05093L9.63614 5.63672L16.0001 12.0007L9.63614 18.3646L8.22192 16.9504L13.1717 12.0007Z">
                    </path>
                </svg>
                <p class="page-name">
                    <?php echo ( get_field('page_name') ); ?>
                </p>
            </div>
        </section>

        <!-- Title Section -->
        <section class="title-section">
            <h2><?php echo nl2br( esc_html( get_field('title') ) ); ?></h2>
        </section>

        <?php echo do_shortcode( '[grw id=1674]' ); ?>
        <div class="readmore">
            <a href="<?php echo ( get_field('google_review_readmore') ); ?>" class="read-more-button">Read More</a>
        </div>



        <!-- Review Section -->
        <section class="review-section">
            <div class="review">
                <?php
                // Arguments for the query
                $args = array(
                    'post_type' => 'review',
                    'posts_per_page' => -1,
                    'orderby' => 'title',
                    'order' => 'ASC',
                );

                // The Query
                $review_query = new WP_Query($args);

                // The Loop
                if ($review_query->have_posts()) {
                    while ($review_query->have_posts()) {
                        $review_query->the_post();
                ?>
                <div class="card-wrap">
                    <div class="review-item">
                        <h2 class="title"><?php the_title(); ?></h2>
                        <div class="row">
                            <?php
                            // Get the repeater field data
                            $review_details = get_field('review_details');
                            if ($review_details) {
                                foreach ($review_details as $detail) {
                            ?>
                            <div class="col-12 col-md-4">
                                <div class="card">
                                    <div class="row g-0">
                                        <div class="col-12 col-md-2">
                                            <div class="profile-pic">
                                                <?php if ($detail['student_profile_pic']) : ?>
                                                <img src="<?php echo $detail['student_profile_pic']; ?>"
                                                    alt="Student Profile Picture">
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-10">
                                            <div class="uni-container">
                                                <?php if ($detail['university_name']) : ?>
                                                <h5 class="university-name"><?php echo $detail['university_name']; ?>
                                                </h5>
                                                <?php endif; ?>
                                                <?php if ($detail['student_name']) : ?>
                                                <p class="student-name"><?php echo $detail['student_name']; ?></p>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="post-container">
                                        <?php if ($detail['student_comment']) : ?>
                                        <p class="student-comment"><?php echo $detail['student_comment']; ?></p>
                                        <button class="see-more-btn">See more</button>
                                        <button class="see-less-btn" style="display:none;">See less</button>
                                        <?php endif; ?>
                                    </div>

                                </div>
                            </div>
                            <?php
                                }
                            } else {
                                echo 'No review details found.';
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <?php
            }
            /* Restore original Post Data */
            wp_reset_postdata();
            } else {
                // No reviews found
                echo 'No reviews found.';
            }
            ?>
            </div>
            <!-- .review -->
        </section>





    </div>
</div>




<?php
get_footer();