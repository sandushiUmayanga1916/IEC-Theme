<?php 
/** 
* Template Name: What we offer Page
*
* @package base_theme
**/ 
get_header();
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
?>

<div class="page-content what-we-offer-page">

    <!-- Hero Section -->
    <section class="hero-section" style="background-color:<?php the_field('background_color'); ?>">
        <div class="row g-0">
            <div class="col-12 col-md-5 col-lg-5 left">
                <div class="hero-text">
                    <h1 data-aos="fade-zoom-in" data-aos-duration="800">
                        <?php echo nl2br( esc_html( get_field('banner_title') ) ); ?></h1>
                    <p data-aos="fade-zoom-in" data-aos-duration="1000">
                        <?php echo nl2br( esc_html( get_field('banner_description') ) ); ?></p>
                    <a href="<?php echo get_permalink(get_page_by_title('Contact Us')); ?>"> <img
                            data-aos="fade-zoom-in" data-aos-duration="1200" class="btn-image img-fluid" width="130"
                            height="100%" src="<?php echo get_home_url() ?>/wp-content/uploads/2024/02/button.png"
                            alt="<?php echo esc_attr($image['title']); ?>" loading="lazy" decoding="async" role="img"
                            aria-label="image">
                    </a>
                </div>
            </div>
            <div class="col-12 col-md-7 col-lg-7 right">
                <?php 
                $image = get_field('banner_image');
                if( !empty( $image ) ): ?>
                <img class="bg-image img-fluid" src="<?php echo esc_url($image['url']); ?>"
                    alt="<?php echo esc_attr($image['title']); ?>" loading="lazy" decoding="async" role="img"
                    aria-label="image">
                <?php endif; ?>
            </div>
        </div>
    </section>

    <div class="container">
        <!-- page navigation -->
        <section class="location-section">
            <div class="locat">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#195d9a">
                    <path
                        d="M20 20C20 20.5523 19.5523 21 19 21H5C4.44772 21 4 20.5523 4 20V11L1 11L11.3273 1.6115C11.7087 1.26475 12.2913 1.26475 12.6727 1.6115L23 11L20 11V20ZM11 13V19H13V13H11Z">
                    </path>
                </svg>
                <p class="page-name1">
                    <?php echo ( get_field('home_name') ); ?>
                </p>
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                    <path
                        d="M13.1717 12.0007L8.22192 7.05093L9.63614 5.63672L16.0001 12.0007L9.63614 18.3646L8.22192 16.9504L13.1717 12.0007Z">
                    </path>
                </svg>
                <p class="page-name">
                    <?php echo ( get_field('page_name') ); ?>
                </p>
            </div>
        </section>



        <!-- Services Section -->
        <section class="services-section">

            <h2><?php echo nl2br( esc_html( get_field('title_2') ) ); ?></h2>
            <?php if (have_rows('point_repeater')): ?>
            <div class="row g-6">
                <?php while (have_rows('point_repeater')): the_row(); ?>
                <div class="col-12 col-md-4 col-lg-4">
                    <div class="card-wrap">
                        <div class="icon-service">
                            <?php 
                                $image = get_sub_field('icon');
                                if( !empty( $image ) ): ?>
                            <img class="bg-image img-fluid" width="60px" height="60px"
                                src="<?php echo esc_url($image['url']); ?>"
                                alt="<?php echo esc_attr($image['title']); ?>" loading="lazy" decoding="async"
                                role="img" aria-label="image">
                            <?php endif; ?>
                        </div>

                        <h4><?php echo get_sub_field('topic'); ?></h4>
                        <p><?php echo get_sub_field('description'); ?></p>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
            <?php endif; ?>

        </section>

    </div>


    <!-- Roadmap Section Desktop -->
    <section class="roadmap-section">
        <h2><?php echo nl2br( esc_html( the_field('roadmap_title') ) ); ?></h2>

        <!-- <div class="roadmap-image">
            <img src="<?php echo nl2br( esc_html( the_field('roadmap-image-dummy') ) ); ?>" class="img-fluid" alt="">
            </div> -->

        <div class="container">
            <div class="logo-section">
                <?php 
                    // Check if there are rows in the repeater field 'roadmap_steps'
                    if( have_rows('roadmap') ): ?>
                <?php 
                        // Loop through each row in the repeater field
                        while( have_rows('roadmap') ): the_row(); ?>
                <div class="item">
                    <div class="image">
                        <?php 
                    // Display the value of the 'roadmap_image' subfield
                    ?>
                        <img src="<?php the_sub_field('roadmap_image'); ?>" alt="" class="image">
                    </div>
                </div>
                <?php endwhile; ?>
                <?php endif; ?>
            </div>

        </div>

        <div class="title-wrap">

            <div class="container">
                <div class="title">
                    <?php 
                // Check if there are rows in the repeater field 'services'
                if( have_rows('roadmap') ): ?>
                    <?php 
                // Loop through each row in the repeater field
                while( have_rows('roadmap') ): the_row(); ?>
                    <div class="logo-title">
                        <?php 
                // Display the value of the 'service_title' subfield
                ?>
                        <h6><?php the_sub_field('roadmap_title'); ?></h6>
                    </div>
                    <?php endwhile; ?>
                    <?php endif; ?>
                </div>

            </div>
        </div>


        <div class="container">
            <?php 
                // Retrieve the value of the standalone image field 'arrow'
                $arrow_image = get_field('arrow');
                ?>
            <div class="description">
                <?php if( have_rows('roadmap') ): ?>
                <?php while( have_rows('roadmap') ): the_row(); ?>
                <div class="logo-description">
                    <?php 
                // Display the standalone image field 'arrow'
                ?>
                    <img src="<?php echo esc_url($arrow_image); ?>" alt="" class="image">
                    <p><?php echo nl2br( esc_html( the_sub_field('roadmap_description') ) ); ?></p>
                </div>
                <?php endwhile; ?>
                <?php endif; ?>
            </div>

        </div>


    </section>


    <!-- Roadmap Section Mobile -->
    <div class="container">
        <section class="road-map-mobile">
            <div class="roadmap">
                <div class="row">
                    <?php 
                    // Check if there are rows in the repeater field 'col_5_4_repeater'
                    if( have_rows('roadmap') ): ?>
                    <?php 
                // Loop through each row in the 'col_5_4_repeater' repeater field
                while( have_rows('roadmap') ): the_row(); ?>

                    <div class="col-5">
                        <!-- This is col-5 -->
                        <div class="image">
                            <img src="<?php echo esc_url( the_sub_field('roadmap_image') ); ?>" alt="" class="image">
                        </div>
                        <div class="logo-title">
                            <h6><?php echo nl2br( esc_html( the_sub_field('roadmap_title') ) ); ?></h6>
                        </div>
                    </div>

                    <div class="col-1">
                        <!-- This is col-1 -->
                        <div class="wrp"></div>
                    </div>
                    <div class="col-2">
                        <!-- This is col-2 -->
                        <div class="arrow">
                            <img src="<?php echo ( the_field('arrow_mobile') ); ?>" alt="" class="image">
                        </div>
                    </div>
                    <div class="col-4">
                        <!-- This is col-4 -->
                        <div class="logo-description">
                            <p><?php echo nl2br( esc_html( the_sub_field('roadmap_description') ) ); ?></p>
                        </div>
                    </div>
                    <?php endwhile; ?>
                    <?php endif; ?>
                </div>

            </div>
        </section>
    </div>

    <!-- <div class="container"> -->

    <!-- Scholarship Section -->
    <!-- <section class="scholarship-section">

            <h2><?php echo nl2br( esc_html( get_field('title_3') ) ); ?></h2>
            <div class="scholarship-form">
                <?php echo apply_shortcodes( '[forminator_form id="403"]' ); ?>
            </div>
            <p class='sub-title'><?php echo get_field('result'); ?></p>
            <?php if (have_rows('card_repeater')): ?>
            <div class="row">
                <?php while (have_rows('card_repeater')): the_row(); ?>
                <div class="col-12 col-md-4 col-lg-4">
                    <div class="card-wrap">
                        <h4><?php echo get_sub_field('scholarship_title'); ?></h4>

                        <div class="row details-courses">
                            <div class='col-12 col-md-4 col-lg-4 '>
                                <div class="schol-column">
                                    <h6><?php echo get_sub_field('amount_title'); ?></h6>
                                    <p><?php echo get_sub_field('amount'); ?></p>
                                </div>
                            </div>

                            <div class='col-12 col-md-4 col-lg-4 schol-column'>
                                <div class="schol-column">
                                    <h6><?php echo get_sub_field('deadline_title'); ?></h6>
                                    <p><?php echo get_sub_field('deadline'); ?></p>
                                </div>
                            </div>

                            <div class='col-12 col-md-4 col-lg-4 schol-column'>
                                <div class="schol-column">
                                    <h6><?php echo get_sub_field('course_title'); ?></h6>
                                    <p><?php echo get_sub_field('course'); ?></p>
                                </div>

                            </div>

                        </div>
                    </div>
                </div>

                <?php endwhile; ?>
            </div>

            <?php endif; ?>

        </section> -->
    <!-- </div> -->



</div>

<?php
get_footer();