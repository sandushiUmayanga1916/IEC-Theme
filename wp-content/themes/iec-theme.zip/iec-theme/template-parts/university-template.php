<?php 
/** 
* Template Name: University Page
*
* @package base_theme
**/ 
get_header();
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

$countryID = isset($_GET['country']) ? $_GET['country'] : '';
$universityID = isset($_GET['university_type']) ? $_GET['university_type'] : '';


?>


<div class="page-content university-page">

    <!-- Hero Section -->
    <section class="hero-section" style="background-color:<?php the_field('background_color'); ?>">
        <div class="row g-0">
            <div class="col-12 col-md-5 col-lg-5 left">
                <div class="hero-text">
                    <h1 data-aos="fade-zoom-in" data-aos-duration="800">
                        <?php echo esc_html( get_field('banner_tittle') ); ?>
                    </h1>
                    <p data-aos="fade-zoom-in" data-aos-duration="1000">
                        <?php echo nl2br( esc_html( get_field('banner_description') ) ); ?></p>

                    <a href="<?php echo get_permalink(get_page_by_title('Contact Us')); ?>"> <img
                            data-aos="fade-zoom-in" data-aos-duration="1200" class="btn-image img-fluid" width="130"
                            height="100%" src="<?php echo get_home_url() ?>/wp-content/uploads/2024/04/button-image.png"
                            alt="<?php echo esc_attr($image['title']); ?>" loading="lazy" decoding="async" role="img"
                            aria-label="image">
                    </a>
                </div>
            </div>
            <div class="col-12 col-md-7 col-lg-7 right">
                <?php 
                $image = get_field('banner_image');
                if( !empty( $image ) ): ?>
                <img class="bg-image img-fluid" width="955" height="637" src="<?php echo esc_url($image['url']); ?>"
                    alt="<?php echo esc_attr($image['title']); ?>" loading="lazy" decoding="async" role="img"
                    aria-label="image">
                <?php endif; ?>
            </div>
        </div>
    </section>


    <!-- Universities Section -->
    <div class="container">
        <!-- page nav -->
        <section class="location-section">
            <div class="locat">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#195d9a">
                    <path
                        d="M20 20C20 20.5523 19.5523 21 19 21H5C4.44772 21 4 20.5523 4 20V11L1 11L11.3273 1.6115C11.7087 1.26475 12.2913 1.26475 12.6727 1.6115L23 11L20 11V20ZM11 13V19H13V13H11Z">
                    </path>
                </svg>
                <p class="page-name1">
                    <?php echo ( get_field('home_name') ); ?>
                </p>
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                    <path
                        d="M13.1717 12.0007L8.22192 7.05093L9.63614 5.63672L16.0001 12.0007L9.63614 18.3646L8.22192 16.9504L13.1717 12.0007Z">
                    </path>
                </svg>
                <p class="page-name">
                    <?php echo ( get_field('page_name') ); ?>
                </p>
            </div>
        </section>


        <!-- Filter Section -->
        <section class="filter-section">

            <!-- university filter -->
            <?php
            // Get the list of countries (parent terms)
            $countries = get_terms(array(
                'taxonomy' => 'country_category', //  taxonomy name
                'parent' => 0,
                'hide_empty' => false,
            ));
            ?>

            <form method="get" id="filter-form">
                <!-- Country Filter -->
                <select name="country_filter" id="country_filter">
                    <option value="">Select Country</option>
                    <?php foreach ($countries as $country) : ?>
                    <option value="<?php echo $country->term_id; ?>"><?php echo $country->name; ?></option>
                    <?php endforeach; ?>
                </select>

                <!-- University Filter -->
                <select name="university_filter" id="university_filter">
                    <option value="">Select University</option>
                </select>
            </form>

            <p class="loading-message">Loading Please Wait......</p>
        </section>


        <div id="posts-container"></div>


        <div id="uni-container">
            <!-- University Section -->
            <section class="university-section">
                <?php
            // Display all posts by default
            $all_posts_html = display_all_posts();
            echo $all_posts_html;
            ?>
            </section>
        </div>

    </div>

    <?php
get_footer();