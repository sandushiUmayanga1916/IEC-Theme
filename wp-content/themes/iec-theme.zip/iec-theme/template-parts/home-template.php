<?php 
/** 
* Template Name: Home Page
*
* @package base_theme
**/ 
get_header();
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
?>

<div class="page-content home-page">

    <!-- Hero Section -->
    <section class="hero-section" style="background-color:<?php the_field('background_color'); ?>">
        <div class="row g-0">
            <div class="col-12 col-md-5 col-lg-5 left">
                <div class="hero-text">
                    <h1 data-aos="fade-zoom-in" data-aos-duration="800">
                        <?php echo nl2br( esc_html( get_field('banner_title') ) ); ?></h1>
                    <p data-aos="fade-zoom-in" data-aos-duration="1000">
                        <?php echo nl2br( esc_html( get_field('banner_description') ) ); ?></p>
                    <a href="<?php echo get_permalink(get_page_by_title('Contact Us')); ?>"> <img
                            data-aos="fade-zoom-in" data-aos-duration="1200" class="btn-image img-fluid" width="130"
                            height="100%" src="<?php echo get_home_url() ?>/wp-content/uploads/2024/02/button.png"
                            alt="<?php echo esc_attr($image['title']); ?>" loading="lazy" decoding="async" role="img"
                            aria-label="image">
                    </a>

                </div>
            </div>
            <div class="col-12 col-md-7 col-lg-7 right">
                <?php 
                $image = get_field('banner_image');
                if( !empty( $image ) ): ?>
                <img class="bg-image img-fluid" src="<?php echo esc_url($image['url']); ?>"
                    alt="<?php echo esc_attr($image['title']); ?>" loading="lazy" decoding="async" role="img"
                    aria-label="image">
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- counter section -->
    <section class="counter-section">
        <div class="container">
            <?php if (have_rows('counter')): ?>
            <div class="row count-section m-auto">
                <?php while (have_rows('counter')): the_row(); ?>
                <div class="col-4 col-md-4 col-lg-4 item">
                    <h2 data-aos="fade-zoom-in" data-aos-duration="1000">
                        <span class="Count" data-count="<?php echo esc_attr(get_sub_field('count')); ?>"></span>+
                    </h2>
                    <h5 data-aos="fade-zoom-in" data-aos-duration="1200">
                        <?php echo nl2br(esc_html(get_sub_field('title'))); ?></h5>
                </div>
                <?php endwhile; ?>
            </div>
            <?php endif; ?>
            <div class="row welcome-section">
                <div class="col-12 col-md-12 col-lg-6 left">
                    <h2><?php echo nl2br( esc_html( get_field('title_I') ) ); ?></h2>
                    <p><?php echo get_field('description'); ?></p>
                    <a href="<?php echo get_permalink(get_page_by_title('About US')); ?>"><img
                            class="btn-image img-fluid" width="130" height="100%"
                            src="<?php echo get_home_url() ?>/wp-content/uploads/2024/02/read-more.png"
                            alt="<?php echo esc_attr($image['title']); ?>" loading="lazy" decoding="async" role="img"
                            aria-label="image"> </a>
                </div>
                <div class="col-12 col-md-12 col-lg-6 right">
                    <?php 
                    $image = get_field('thumbnail_image');
                    if( !empty( $image ) ): ?>
                    <img class="bg-image img-fluid" width="100%" height="100%"
                        src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['title']); ?>"
                        loading="lazy" decoding="async" role="img" aria-label="image">
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <!-- journey section -->
    <section class="journey-section">
        <div class="container">

            <h2><?php echo nl2br( esc_html( get_field('title_II') ) ); ?></h2>


            <?php if (have_rows('point_repeater')): ?>
            <div class="row">
                <?php while (have_rows('point_repeater')): the_row(); ?>
                <div class="col-12 col-md-12 col-lg-4 text-center card-wrap">
                    <?php 
                        $image = get_sub_field('icon');
                        if( !empty( $image ) ): ?>
                    <img class="bg-image img-fluid" width="60px" height="60px"
                        src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['title']); ?>"
                        loading="lazy" decoding="async" role="img" aria-label="image">
                    <?php endif; ?>
                    <h3><?php echo get_sub_field('topic'); ?></h3>
                    <p><?php echo get_sub_field('description'); ?></p>
                </div>
                <?php endwhile; ?>
            </div>
            <?php endif; ?>
        </div>
    </section>


    <!-- partner section -->
    <section class="partner-section">
        <div class="container-fluid">
            <h2><?php echo nl2br( esc_html( get_field('title_iii') ) ); ?></h2>
            <?php if (have_rows('logos_list')): ?>
            <div class="constant-partner-slider" id=""
                data-slick='{"slidesToShow": 6, "slidesToScroll": 1, "infinite": true, "arrows":false, "autoplay":true, "autoplaySpeed":0, "responsive":[{"breakpoint": 768, "settings":{"slidesToShow":4 }},{"breakpoint": 480, "settings":{"slidesToShow":4 }}]}'>
                <?php while (have_rows('logos_list')): the_row(); ?>
                <div class="item">
                    <?php 
                    $image = get_sub_field('logo');
                    if( !empty( $image ) ): ?>
                    <img class="img-fluid" src="<?php echo esc_url($image['url']); ?>"
                        alt="<?php echo esc_attr($image['title']); ?>" loading="lazy" decoding="async" role="img"
                        aria-label="image">
                    <?php endif; ?>
                </div>
                <?php endwhile; ?>
            </div>
            <?php endif; ?>
        </div>
    </section>


    <!-- testimonials section -->
    <section class="testimonials-section">
        <div class="container-fluid">
            <?php 
            $image = get_field('background_image');
            if( !empty( $image ) ): ?>

            <?php endif; ?>
            <div class="background" style="background-image: url('<?php echo esc_url($image['url']); ?>');">

                <div class="row-wrap">
                    <div class="row">
                        <div class="col-12 col-md-12 col-lg-5 left">
                            <h2><?php echo nl2br( esc_html( get_field('title_iv') ) ); ?></h2>
                        </div>
                        <div class="col-12 col-md-12 col-lg-7 right">
                            <img class="quarts-icon img-fluid" width="200px" height="100px"
                                src="<?php echo get_template_directory_uri() ?>/assets/images/icon.png"
                                alt="<?php echo esc_attr($image['title']); ?>" loading="lazy" decoding="async"
                                role="img" aria-label="image">
                            <!-- <script src="https://widget.trustmary.com/bibntxboG"></script> -->
                            <?php echo do_shortcode( '[grw id=1674]' ); ?>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>


    <!-- local partner section -->
    <section class="local-partner-section">
        <div class="container-fluid">
            <h2><?php echo nl2br(esc_html(get_field('title_v'))); ?></h2>
            <?php if (have_rows('logos_list_local')): ?>
            <div class="constant-local-slider">
                <?php while (have_rows('logos_list_local')): the_row(); ?>
                <div class="item">
                    <?php
                    $image = get_sub_field('logo');
                    if (!empty($image)): ?>
                    <img class="local-logo img-fluid" src="<?php echo esc_url($image['url']); ?>"
                        alt="<?php echo esc_attr($image['alt']); ?>" loading="lazy" decoding="async" role="img"
                        aria-label="image">
                    <?php endif; ?>
                </div>
                <?php endwhile; ?>
            </div>
            <?php endif; ?>
        </div>
    </section>



    <!-- destination-section -->
    <section class="destination-section">
        <div class="container">
            <h2><?php echo nl2br(esc_html(get_field('title_vi'))); ?></h2>
            <div class="row">
                <?php
            $taxonomy_name = 'country_category';
            $terms = get_terms(array(
                'taxonomy' => $taxonomy_name,
                'hide_empty' => false,
                'parent' => 0 // Get only top-level categories
            ));

            if (!empty($terms)) {
                foreach ($terms as $term) {
                    $term_image_url = z_taxonomy_image_url($term->term_id); // Use Categories Images plugin function
            ?>
                <div class="col-12 col-md-12 col-lg-6">
                    <div class="card">
                        <?php if ($term_image_url) { ?>
                        <img class="card-image" src="<?php echo esc_url($term_image_url); ?>"
                            alt="<?php echo esc_attr($term->name); ?>">
                        <?php } ?>
                        <div class="row g-0">
                            <div class="col-12 col-md-8 col-lg-8">
                                <div class="card-wrap">
                                    <h3>Study in <?php echo esc_html($term->name); ?> <?php
                                        $country_flag_image_id = get_term_meta($term->term_id, 'country_flag', true);
                                        if ($country_flag_image_id) {
                                            $country_flag_image_url = wp_get_attachment_image_url($country_flag_image_id, 'full');
                                            ?>
                                        <img src="<?php echo esc_url($country_flag_image_url); ?>"
                                            alt="<?php echo esc_attr($term->name); ?> Country Flag" class="std-prf">
                                        <?php } ?>
                                    </h3>

                                </div>

                            </div>
                            <div class="col-12 col-md-4 col-lg-4">
                                <div class="btn-img-wrap">
                                    <?php
                                    // Assuming you're already in a loop for the terms of the country_category taxonomy
                                    $button_repeater = get_field('button_repeater', $term); // Assuming $term is the current term object

                                    if ($button_repeater): // Check if the repeater field exists for the current term
                                        while (have_rows('button_repeater', $term)) : the_row(); // Loop through the rows of the repeater field
                                            $button_url = get_sub_field('button_url'); // Retrieve the button URL
                                    ?>
                                    <a href="<?php echo esc_url($button_url); ?>">
                                        <img class="btn-image img-fluid" width="130" height="100%"
                                            src="<?php echo get_home_url() ?>/wp-content/uploads/2024/02/Group-580.png"
                                            alt="<?php echo esc_attr($image['title']); ?>" loading="lazy"
                                            decoding="async" role="img" aria-label="image">
                                    </a>
                                    <?php
    endwhile;
endif;
?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php }
            } ?>
            </div>
        </div>
    </section>


    <?php
get_footer();