<?php
/**
 * base_theme Theme Customizer
 *
 * @package base_theme
 */

//Theme Options

// Set up the WordPress Theme logo feature.
 add_theme_support( 'custom-logo' );

// Add support for responsive embedded content.
add_theme_support( 'responsive-embeds' );

//Enable support for Post Thumbnails on posts and pages.
add_theme_support( 'post-thumbnails' );

//Enable Menu
add_theme_support( 'menus' );

//Enable Tag
add_theme_support( 'title-tag' );

// Enable HTML5 markup for search form, comment form, and comments
add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption'));

// Enable support for post formats (e.g., video, audio)
add_theme_support('post-formats', array('video', 'audio'));

// Add excerpts to pages
add_post_type_support('page', 'excerpt');

// Enable automatic feed links (RSS)
add_theme_support('automatic-feed-links');

// Enable selective refresh for widgets in the customizer
add_theme_support('customize-selective-refresh-widgets');

// Enable support for wide and full-width alignment for blocks
// add_theme_support('align-wide');

//login page Styles
function enqueue_custom_login_styles() {
    wp_enqueue_style('custom-login-styles', get_template_directory_uri() . '/css/login-styles.css', array(), '1.0', 'all');
}
add_action('login_enqueue_scripts', 'enqueue_custom_login_styles');

// remove default editor
// add_filter( 'use_block_editor_for_post', '__return_false' );

//Prevent self-pingbacks from your own site.
function disable_self_pingbacks($links) {
    foreach ($links as $l => $link)
        if (0 === strpos($link, get_option('home')))
            unset($links[$l]);
    return $links;
}
add_action('pre_ping', 'disable_self_pingbacks');

//Remove WordPress Version from Head: Enhance security
function remove_wp_version() {
    return '';
}
add_filter('the_generator', 'remove_wp_version');

// Remove WordPress Version from Dashboard Footer
function remove_wp_version_from_footer() {
    remove_filter('update_footer', 'core_update_footer');
}
add_action('admin_menu', 'remove_wp_version_from_footer');


//Add Custom Dashboard Footer Text:
function custom_dashboard_footer() {
    echo 'All Rights Reserved. Developed by Chamod Tharuka</a>';
}
add_filter('admin_footer_text', 'custom_dashboard_footer');


//acf option page
if( function_exists('acf_add_options_page') ) {
	acf_add_options_page(array(
		'page_title' 	=> 'Theme Options',
		'menu_title'	=> 'Theme Options',
		'menu_slug' 	=> 'theme-general-settings',
		'capability'	=> 'edit_posts',
        'icon_url' =>   'dashicons-admin-generic',
		'position'      => 3,
		'redirect'		=> true
	));
	
	acf_add_options_sub_page(array(
		'page_title' 	=> 'Theme Footer Settings',
		'menu_title'	=> 'Footer',
		'parent_slug'	=> 'theme-general-settings',
	));
	
}


/**
 * Filters wp_title to print a neat <title> tag based on what is being viewed.
 *
 * @param string $title Default title text for current view.
 * @param string $sep   Optional separator.
 * @return string The filtered title.
 */
function theme_title( $title, $sep ) {
    if ( is_feed() ) {
        return $title;
    }
     
    global $page, $paged;
 
    // Add the blog name
    $title .= get_bloginfo( 'name', 'display' );
 
    // Add the blog description for the home/front page.
    $site_description = get_bloginfo( 'description', 'display' );
    if ( $site_description && ( is_home() || is_front_page() ) ) {
        $title .= " $sep $site_description";
    }
 
    // Add a page number if necessary:
    if ( ( $paged >= 2 || $page >= 2 ) && ! is_404() ) {
        $title .= " $sep " . sprintf( __( 'Page %s', '_s' ), max( $paged, $page ) );
    }
    return $title;
}
add_filter( 'wp_title', 'theme_title', 10, 2 );


/**
* Register Custom Navigation Walker
**/
function register_navwalker(){
	require_once get_template_directory() . '/inc/class-wp-bootstrap-navwalker.php';
}
add_action( 'after_setup_theme', 'register_navwalker' );

add_filter( 'nav_menu_link_attributes', 'prefix_bs5_dropdown_data_attribute', 20, 3 );
/**
 * Use namespaced data attribute for Bootstrap's dropdown toggles.
 *
 * @param array    $atts HTML attributes applied to the item's `<a>` element.
 * @param WP_Post  $item The current menu item.
 * @param stdClass $args An object of wp_nav_menu() arguments.
 * @return array
 */
function prefix_bs5_dropdown_data_attribute( $atts, $item, $args ) {
    if ( is_a( $args->walker, 'WP_Bootstrap_Navwalker' ) ) {
        if ( array_key_exists( 'data-toggle', $atts ) ) {
            unset( $atts['data-toggle'] );
            $atts['data-bs-toggle'] = 'dropdown';
        }
    }
    return $atts;
}

// Add Menu locations
register_nav_menus( array(
    'primary' => __( 'Primary Menu', 'base_theme'),
    'secondary' => __( 'Secondary Menu', 'base_theme'),
) );

// Change Login logo Icon
function my_login_logo() {
    $custom_logo_id = get_theme_mod('custom_logo');
    $logo = wp_get_attachment_image_src($custom_logo_id, 'full');

    if ($logo) {
        $logo_url = esc_url($logo[0]);
    } else {
        // If no logo is set, you can provide a default URL here
        $logo_url = get_stylesheet_directory_uri() . '/assets/images/default-logo.png';
    }
    ?>
<style type="text/css">
#login h1 a,
.login h1 a {
    background-image: url(<?php echo $logo_url; ?>);
    height: 52px;
    width: 100%;
    background-size: contain;
    background-repeat: no-repeat;
}
</style>
<?php
}
add_action( 'login_enqueue_scripts', 'my_login_logo' );

// Remove default block libry css
function remove_block_library_css(){
    wp_dequeue_style( 'wp-block-library' );
    wp_dequeue_style( 'wp-block-library-theme' );
    wp_dequeue_style( 'wc-block-style' );
}
add_action( 'wp_enqueue_scripts', 'remove_block_library_css', 100 );
