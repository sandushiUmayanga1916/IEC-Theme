<?php
/**
 * Enqueue scripts and styles.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 *
 * @package base_theme
 */

 //Enqueue theme styles
 function base_theme_style(){

    // Enqueue your main theme stylesheet
    wp_enqueue_style('theme-style', get_stylesheet_uri());

     wp_register_style('theme', get_template_directory_uri() . '/css/theme.css', array(), false, 'all');
     wp_enqueue_style('theme');

     wp_register_style('remixiconcdn', 'https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css', array(), false, 'all');
     wp_enqueue_style('remixiconcdn');
     
     wp_register_style('litepickercss', 'https://cdn.jsdelivr.net/npm/litepicker/dist/css/litepicker.css', array(), false, 'all');
     wp_enqueue_style('litepickercss');

    // Enqueue Slick CSS
    wp_enqueue_style('slickcss', 'https://cdn.jsdelivr.net/jquery.slick/1.5.8/slick.css', array(), false, 'all');
    wp_enqueue_style('slickthemecss', 'https://cdn.jsdelivr.net/jquery.slick/1.5.8/slick-theme.css', array(), false, 'all');

 }
 add_action('wp_enqueue_scripts','base_theme_style');

// Filter to add async loading for specific styles - start
function add_async_attribute_to_style($html, $handle) {
    $async_styles = ['remixiconcdn']; 

    if (in_array($handle, $async_styles)) {
        return str_replace("rel='stylesheet'", "rel='stylesheet' media='none' onload='if(media!=\"all\")media=\"all\"'", $html);
    }
    return $html;
}
add_filter('style_loader_tag', 'add_async_attribute_to_style', 10, 2);
// Filter to add async loading for specific styles - end

// Enqueue theme scripts
 function base_theme_scripts(){

    wp_enqueue_script('jquery');

     wp_register_script('theme', get_template_directory_uri() . '/js/theme.js','jquery',false,true);
     wp_enqueue_script('theme');

     wp_register_script('boostrapbundle', get_template_directory_uri() . '/js/bootstrap.bundle.min.js','jquery',false,true);
     wp_enqueue_script('boostrapbundle');

    //  For front page
     if (is_front_page()) {
        wp_register_script('OwlCarousel2js', 'https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js','jquery',false,true);
     wp_enqueue_script('OwlCarousel2js');

        wp_register_script('slickjs', 'https://cdn.jsdelivr.net/jquery.slick/1.5.8/slick.min.js', array('jquery'), false, true);
    wp_enqueue_script('slickjs');
     }    
 }
 add_action('wp_enqueue_scripts', 'base_theme_scripts');