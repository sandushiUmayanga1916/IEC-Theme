<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package base_theme
 */
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
?>
<footer class="footer">
    <div class="footer-top">
        <div class="container">
            <div class="row footer-top-wrap">
                <div class="col-12 col-md-12 col-lg-5 one">
                    <?php 
                $image = get_field('footer_logo_1', 'option');
                if( !empty( $image ) ): ?>
                    <img class="footer-logo-1" src="<?php echo esc_url($image['url']); ?>" alt="logo">
                    <?php endif; ?>
                    <?php 
                $image = get_field('footer_logo_2', 'option');
                if( !empty( $image ) ): ?>
                    <img class="footer-logo-2" src="<?php echo esc_url($image['url']); ?>" alt="logo">
                    <?php endif; ?>
                </div>
                <div class="col-12 col-md-12 col-lg-3 two">
                    <h4><?php echo get_field('footer_menu_name', 'option'); ?></h4>
                    <?php if (have_rows('footer_menu', 'option')): ?>
                    <ul>
                        <?php while (have_rows('footer_menu', 'option')): the_row(); ?>
                        <li><a href="<?php echo get_sub_field('url'); ?>"><?php echo get_sub_field('name'); ?></a></li>
                        <?php endwhile; ?>
                    </ul>
                    <?php endif; ?>
                </div>
                <div class="col-12 col-md-12 col-lg-4 three">
                    <h4>Contact us</h4>
                    <?php if (have_rows('contact_us', 'option')): ?>
                    <ul>
                        <?php while (have_rows('contact_us', 'option')): the_row(); ?>
                        <li><i class="<?php echo get_sub_field('icon'); ?>"></i> <a
                                href="<?php echo get_sub_field('value'); ?>"><?php echo get_sub_field('text'); ?></a>
                        </li>
                        <?php endwhile; ?>
                    </ul>
                    <?php endif; ?>

                    <?php if (have_rows('social_media', 'option')): ?>
                    <ul class="social-icons">
                        <?php while (have_rows('social_media', 'option')): the_row(); ?>

                        <li>
                            <a href="<?php echo get_sub_field('url'); ?>">
                                <?php 
                        $image = get_sub_field('social_icon', 'option');
                        if( !empty( $image ) ): ?>
                                <img src="<?php echo esc_url($image['url']); ?>" alt="logo">
                                <?php endif; ?>
                            </a>
                        </li>
                        <?php endwhile; ?>

                    </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>



    <div class="footer-bottom">
        <div class="container">
            <div class="footer-bottom-wrap">
                <p>©<?php echo date("Y"); ?> IEC. All rights reserved.</p>
                <p>Design & Developed by <a href="https://www.enfection.com/" target="_blank"> Enfection</a></p>
            </div>
        </div>
    </div>
</footer>

</div><!-- #page we need this extra closing tag here -->

<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>


<?php wp_footer(); ?>


</html>