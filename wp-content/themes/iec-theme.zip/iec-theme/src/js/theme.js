AOS.init();
// Add all JS development here
jQuery(function ($) {
  $(document).ready(function () {


    //about us owl for news carousel
    $(document).ready(function () {
      // Initialize Owl Carousel
      $("#carousel1").owlCarousel({
        autoplay: true,
        rewind: true,
        margin: 20,
        responsiveClass: true,
        autoHeight: true,
        autoplayTimeout: 7000,
        smartSpeed: 800,
        nav: true,
        responsive: {
          0: {
            items: 1
          },
          600: {
            items: 2
          },
          1024: {
            items: 3
          },
          1366: {
            items: 3
          },
        },

      });

    });

    jQuery(document).ready(function ($) {
      // Handle click on popup-trigger
      $(document).on('click', '.popup-trigger', function (e) {
        e.preventDefault();
        var newsImage = $(this).closest('.item').data('image-src');
        var newsDescription = $(this).closest('.item').data('description');
        $('#popup-image').attr('src', newsImage);
        $('#popup-description').text(newsDescription);
        $('#popup').fadeIn();
      });

      // Handle click on close button
      $(document).on('click', '.popup-container .close', function () {
        $('#popup').fadeOut();
      });

      // Close popup when clicking outside of it
      $(document).on('click', function (e) {
        if (!$(e.target).closest('.popup-content').length && !$(e.target).closest('.popup-trigger').length) {
          $('#popup').fadeOut();
        }
      });
    });

    //about us owl for event carousel
    $(document).ready(function () {
      $("#carousel2").owlCarousel({
        autoplay: true,
        rewind: true, /* use rewind if you don't want loop */
        margin: 20,
        /*
        animateOut: 'fadeOut',
        animateIn: 'fadeIn',
        */
        responsiveClass: true,
        autoHeight: true,
        autoplayTimeout: 7000,
        smartSpeed: 800,
        nav: true,
        responsive: {
          0: {
            items: 1
          },

          600: {
            items: 2
          },

          1024: {
            items: 3
          },

          1366: {
            items: 3
          }
        }
      });
    });

    //about us owl for gallery carousel
    $(document).ready(function () {
      $("#carousel3").owlCarousel({
        autoplay: true,
        rewind: true, /* use rewind if you don't want loop */
        margin: 20,
        /*
        animateOut: 'fadeOut',
        animateIn: 'fadeIn',
        */
        responsiveClass: true,
        autoHeight: true,
        autoplayTimeout: 7000,
        smartSpeed: 800,
        nav: true,
        responsive: {
          0: {
            items: 1
          },

          600: {
            items: 2
          },

          1024: {
            items: 3
          },

          1366: {
            items: 3
          }
        }
      });
    });



    //Navbar Scrollspy 
    // $(window).scroll(function () {
    //     var scroll = $(window).scrollTop();
    //     if (scroll > 80) {
    //         $(".inner").addClass("affix");
    //     } else {
    //         $(".inner").removeClass("affix");
    //     }
    // });





    $(document).ready(function () {
      // Navbar Close after click
      $(document).on('click', function () {
        $('.navbar .collapse').collapse('hide');
      });

      // Mobile Menu hamburger
      $(".hamburger").click(function () {
        $(this).toggleClass("is-active");
      });

      // Start Navbar Scroll effect
      var prevScrollpos = window.pageYOffset;
      var navbarHeight = $('.navbar').outerHeight();

      $(window).scroll(function () {
        var currentScrollPos = window.pageYOffset;
        if (prevScrollpos > currentScrollPos) {
          $('.navbar').css('top', '0');
        } else {
          if (currentScrollPos > navbarHeight) {
            $('.navbar').css('top', '-' + navbarHeight + 'px');
          }
        }
        prevScrollpos = currentScrollPos;
      });
      // End Navbar Scroll effect

      // Counter animation
      var countersAnimated = false;

      function animateCounters() {
        $('.Count').each(function () {
          var $this = $(this);
          var targetCount = parseInt($this.attr('data-count'));
          var countStr = targetCount.toString();
          var firstDigit = countStr.charAt(0);
          var remainingDigits = countStr.slice(1);

          var html = '<span class="first-digit">' + firstDigit + '</span>';
          if (targetCount >= 1000) {
            html += ',';
          }
          html += '<span class="remaining-digits">' + remainingDigits + '</span>';

          $this.empty().append(html);

          jQuery({ Counter: 0 }).animate({ Counter: targetCount }, {
            duration: 1000,
            easing: 'swing',
            step: function () {
              $this.find('.remaining-digits').text(Math.ceil(this.Counter).toString().slice(1));
            }
          });
        });
      }

      $(window).scroll(function () {
        var windowHeight = $(window).height();
        var windowScrollTop = $(window).scrollTop();
        var sectionOffset = $('.count-section').offset().top;

        if (!countersAnimated && windowScrollTop + windowHeight > sectionOffset) {
          animateCounters();
          countersAnimated = true;
        }
      });

      // Remove backdrop elements
      $('.offcanvas-backdrop.fade.show').remove();
      $('.modal-backdrop.fade.show').remove();
    });



    // Home page insitutional partners carosel
    var $s = $('.constant-partner-slider').slick({
      cssEase: 'linear',
      speed: 7000,
      autoplay: true,
      pauseOnHover: false,
      slidesToShow: 6, // Number of slides to show initially
      responsive: [
        {
          breakpoint: 768, // Medium devices (tablets, 768px and up)
          settings: {
            slidesToShow: 2 // Number of slides to show at this breakpoint
          }
        }
      ]
    });

    $('.gotoright').click(function ($) {
      $s.slick("setOption", "speed", 1, false)
    });
    $('.gotoleft').click(function ($) {
    });


    // Home page testimonials carosel
    $('.owl-carousel').owlCarousel({
      loop: true,
      margin: 10,
      nav: false,
      responsive: {
        0: {
          stagePadding: 0,
          items: 1
        },
        600: {
          stagePadding: 0,
          items: 1
        },
        1000: {
          stagePadding: 80,
          items: 2
        }
      }
    })

    // Home page our local partners carosel
    var $s = $('.constant-local-slider').slick({
      cssEase: 'linear',
      speed: 7000,
      autoplay: true,
      pauseOnHover: false,
      slidesToShow: 6, // Number of slides to show initially
      responsive: [
        {
          breakpoint: 768, // Medium devices (tablets, 768px and up)
          settings: {
            slidesToShow: 2 // Number of slides to show at this breakpoint
          }
        }
      ]
    });

    $('.gotoright').click(function ($) {

    });
    $('.gotoleft').click(function ($) {
      $s.slick("setOption", "speed", 1, false)
    });


  });

  // see more in review page
  document.querySelectorAll('.see-more-btn').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const studentComment = this.previousElementSibling;
      studentComment.style.maxHeight = 'none';
      studentComment.style.overflow = 'visible';
      this.style.display = 'none';
      this.nextElementSibling.style.display = 'inline-block';
    });
  });

  document.querySelectorAll('.see-less-btn').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const studentComment = this.previousElementSibling.previousElementSibling;
      studentComment.style.maxHeight = '6.3rem';
      studentComment.style.overflow = 'hidden';
      this.style.display = 'none';
      this.previousElementSibling.style.display = 'inline-block';
    });
  });



  // filter in university representation page
  jQuery(document).ready(function ($) {

    // Function to update URL with filters using hash fragments
    function updateUrlWithFilters(countryID, universityID) {
      var hashParams = [];

      if (countryID) {
        hashParams.push('country=' + encodeURIComponent(countryID));
      }

      if (universityID) {
        hashParams.push('university=' + encodeURIComponent(universityID));
      }

      var hash = hashParams.join('&');

      // Update URL hash fragment
      window.location.hash = hash;
    }


    // Function to apply filters based on URL hash fragment
    function applyFiltersFromUrlHash() {
      var hash = window.location.hash.substring(1);
      var params = hash.split('&');
      var countryID, universityID;

      params.forEach(function (param) {
        var pair = param.split('=');
        if (pair[0] === 'country') {
          countryID = decodeURIComponent(pair[1]);
        } else if (pair[0] === 'university') {
          universityID = decodeURIComponent(pair[1]);
        }
      });

      if (countryID) {
        $('#country_filter').val(countryID);
        // Trigger change event for country filter
        $('#country_filter').change();
      }

      if (universityID) {
        $('#university_filter').val(universityID);
        // Trigger change event for university filter
        $('#university_filter').change();
      }
    }

    // Read URL hash fragment parameters and apply filters on page load
    applyFiltersFromUrlHash();

    // Event handler for country filter change
    $('#country_filter').on('change', function () {
      var countryID = $(this).val();
      var universityID = $('#university_filter').val();

      // Reset university filter and posts container
      $('#university_filter').html('<option value="">Select University</option>');
      $('#posts-container').html('');
      $('#uni-container').html('');

      if (countryID) {
        // Show loading indicator
        $('.loading-message').addClass('loading');

        // Make AJAX request to fetch universities
        $.ajax({
          url: ajaxObject.admin_url,
          type: 'POST',
          data: {
            action: 'get_universities',
            country_id: countryID,
          },
          success: function (response) {
            $('#university_filter').html(response);
            // Fetch and display posts for selected country
            fetchAndDisplayPosts(countryID, universityID);

            // Update URL with selected country filter
            updateUrlWithFilters(countryID, '');
          },
          error: function () {
            $('#university_filter').html('<option value="">Select University</option>');
            $('#posts-container').html('<p>No universities found for the selected country.</p>');
            // Hide loading message
            $('.loading-message').removeClass('loading');
          },
        });
      } else {
        // Clear posts container
        $('#posts-container').html('');
        $('#uni-container').css('display', 'none');
        // Hide loading message
        $('.loading-message').removeClass('loading');

        // Update URL by removing filters
        updateUrlWithFilters('', '');
      }
    });

    // Event handler for university filter change
    $('#university_filter').on('change', function () {
      var countryID = $('#country_filter').val();
      var universityID = $(this).val();

      if (countryID && universityID) {
        // Make AJAX request to fetch posts for both country and university
        fetchAndDisplayPosts(countryID, universityID);

        // Update URL with selected country and university filters
        updateUrlWithFilters(countryID, universityID);
      } else {
        // Clear posts container if either country or university is not selected
        $('#uni-container').css('display', 'none');
        $('#posts-container').html('');

        // Update URL with selected country filter (if any)
        updateUrlWithFilters(countryID, '');
      }
    });

    // Function to fetch and display posts
    function fetchAndDisplayPosts(countryID, universityID) {
      // Make AJAX request to fetch posts for selected country
      $.ajax({
        url: ajaxObject.admin_url,
        type: 'POST',
        data: {
          action: 'get_posts',
          country_id: countryID,
          university_id: universityID,
        },
        success: function (response) {
          $('#uni-container').css('display', 'block');
          $('#posts-container').html(response);
          // Hide loading message
          $('.loading-message').removeClass('loading');
        },
        error: function () {
          $('#uni-container').css('display', 'none');
          $('#posts-container').html('<p>No posts found.</p>');
          // Hide loading message
          $('.loading-message').removeClass('loading');
        },
      });
    }
  });



  // taxonomy page dropdown
  function redirectToURL() {
    var dropdown = document.getElementById("urlDropdown");
    var selectedURL = dropdown.value;
    if (selectedURL) {
      window.location.href = selectedURL;
    }
  }

  document.getElementById("urlDropdown").addEventListener("change", redirectToURL);

});