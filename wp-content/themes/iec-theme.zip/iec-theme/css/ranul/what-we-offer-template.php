<?php 
/** 
* Template Name: What we offer Page
*
* @package base_theme
**/ 
get_header();
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
?>

<div class="page-content what-we-offer-page">

    <!-- Hero Section -->
    <section class="hero-section" style="background-color:<?php the_field('background_color'); ?>">
        <div class="row g-0">
            <div class="col-12 col-md-6 col-lg-6 left">
                <div class="hero-text">
                    <h1 data-aos="fade-zoom-in" data-aos-duration="800">
                        <?php echo nl2br( esc_html( get_field('banner_title') ) ); ?></h1>
                    <p data-aos="fade-zoom-in" data-aos-duration="1000">
                        <?php echo nl2br( esc_html( get_field('banner_description') ) ); ?></p>
                    <a href="<?php echo get_field('talk_to_us'); ?>"> <img data-aos="fade-zoom-in"
                            data-aos-duration="1200" class="btn-image img-fluid" width="130" height="100%"
                            src="<?php echo get_home_url() ?>/wp-content/uploads/2024/02/button.png"
                            alt="<?php echo esc_attr($image['title']); ?>" loading="lazy" decoding="async" role="img"
                            aria-label="image">
                    </a>
                </div>
            </div>
            <div class="col-12 col-md-6 col-lg-6 right">
                <?php 
                $image = get_field('banner_image');
                if( !empty( $image ) ): ?>
                <img class="bg-image img-fluid" width="955" height="637" src="<?php echo esc_url($image['url']); ?>"
                    alt="<?php echo esc_attr($image['title']); ?>" loading="lazy" decoding="async" role="img"
                    aria-label="image">
                <?php endif; ?>
            </div>
        </div>
    </section>

    <div class="container">
        <!-- page navigation -->
        <section class="location-section">
            <div class="locat">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="blue">
                    <path
                        d="M20 20C20 20.5523 19.5523 21 19 21H5C4.44772 21 4 20.5523 4 20V11L1 11L11.3273 1.6115C11.7087 1.26475 12.2913 1.26475 12.6727 1.6115L23 11L20 11V20ZM11 13V19H13V13H11Z">
                    </path>
                </svg>
                <p class="page-name1">
                    <?php echo ( get_field('home_name') ); ?>
                </p>
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                    <path
                        d="M13.1717 12.0007L8.22192 7.05093L9.63614 5.63672L16.0001 12.0007L9.63614 18.3646L8.22192 16.9504L13.1717 12.0007Z">
                    </path>
                </svg>
                <p class="page-name">
                    <?php echo ( get_field('page_name') ); ?>
                </p>
            </div>
        </section>



        <!-- Services Section -->
        <section class="services-section">

            <h2><?php echo nl2br( esc_html( get_field('title_2') ) ); ?></h2>
            <?php if (have_rows('point_repeater')): ?>
            <div class="row g-6">
                <?php while (have_rows('point_repeater')): the_row(); ?>
                <div class="col-12 col-md-4 col-lg-4">
                    <div class="card-wrap">
                        <div class="icon-service">
                            <?php 
            $image = get_sub_field('icon');
            if( !empty( $image ) ): ?>
                            <img class="bg-image img-fluid" width="60px" height="60px"
                                src="<?php echo esc_url($image['url']); ?>"
                                alt="<?php echo esc_attr($image['title']); ?>" loading="lazy" decoding="async"
                                role="img" aria-label="image">
                            <?php endif; ?>
                        </div>

                        <h4><?php echo get_sub_field('topic'); ?></h4>
                        <p><?php echo get_sub_field('description'); ?></p>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
            <?php endif; ?>

        </section>


        <!-- Roadmap Section -->
        <section class="roadmap-section">
            <h2><?php echo nl2br( esc_html( get_field('roadmap_title') ) ); ?></h2>
            <div class="logo-section">
                <div class="item">
                    <div class="image">
                        <img src="<?php echo ( get_field('initial_consultation') ); ?>" alt="" class="image">
                    </div>
                </div>
                <div class="item">
                    <div class="image">
                        <img src="<?php echo ( get_field('application_assistance') ); ?>" alt="" class="image">
                    </div>
                </div>
                <div class="item">
                    <div class="image">
                        <img src="<?php echo ( get_field('financial_planning') ); ?>" alt="" class="image">
                    </div>
                </div>
                <div class="item">
                    <div class="image">
                        <img src="<?php echo ( get_field('visa_guidance') ); ?>" alt="" class="image">
                    </div>
                </div>
                <div class="item">
                    <div class="image">
                        <img src="<?php echo ( get_field('support_till_the_end') ); ?>" alt="" class="image">
                    </div>
                </div>
            </div>

            <div class="title">
                <div class="logo-title">
                    <h6><?php echo nl2br( esc_html( get_field('initial_consultation') ) ); ?></h6>
                </div>
                <div class="logo-title">
                    <h6><?php echo nl2br( esc_html( get_field('application_assistance') ) ); ?></h6>
                </div>
                <div class="logo-title">
                    <h6><?php echo nl2br( esc_html( get_field(' financial_planning') ) ); ?></h6>
                </div>
                <div class="logo-title">
                    <h6><?php echo nl2br( esc_html( get_field('visa_guidance') ) ); ?></h6>
                </div>
                <div class="logo-title">
                    <h6><?php echo nl2br( esc_html( get_field('support_till_the_end') ) ); ?></h6>
                </div>
            </div>

            <div class="description">
                <div class="logo-description">
                    <img src="<?php echo ( get_field('arrow') ); ?>" alt="" class="image">
                    <p><?php echo nl2br( esc_html( get_field('consultation_description') ) ); ?></p>
                </div>
                <div class="logo-description">
                    <img src="<?php echo ( get_field('arrow') ); ?>" alt="" class="image">
                    <p><?php echo nl2br( esc_html( get_field('application_description') ) ); ?></p>
                </div>
                <div class="logo-description">
                    <img src="<?php echo ( get_field('arrow') ); ?>" alt="" class="image">
                    <p><?php echo nl2br( esc_html( get_field('financial_description') ) ); ?></p>
                </div>
                <div class="logo-description">
                    <img src="<?php echo ( get_field('arrow') ); ?>" alt="" class="image">
                    <p><?php echo nl2br( esc_html( get_field('guidance_description') ) ); ?></p>
                </div>
                <div class="logo-description">
                    <img src="<?php echo ( get_field('arrow') ); ?>" alt="" class="image">
                    <p><?php echo nl2br( esc_html( get_field('support_description') ) ); ?></p>
                </div>
            </div>

        </section>

        <!-- Scholarship Section -->
        <section class="scholarship-section">

            <h2><?php echo nl2br( esc_html( get_field('title_3') ) ); ?></h2>
            <div class="scholarship-form">
                <?php echo apply_shortcodes( '[forminator_form id="403"]' ); ?>
            </div>
            <p class='sub-title'><?php echo get_field('result'); ?></p>
            <?php if (have_rows('card_repeater')): ?>
            <div class="row">
                <?php while (have_rows('card_repeater')): the_row(); ?>
                <div class="col-12 col-md-4 col-lg-4">
                    <div class="card-wrap">
                        <h4><?php echo get_sub_field('scholarship_title'); ?></h4>

                        <div class="row details-courses">
                            <div class='col-12 col-md-4 col-lg-4 '>
                                <div class="schol-column">
                                    <h6><?php echo get_sub_field('amount_title'); ?></h6>
                                    <p><?php echo get_sub_field('amount'); ?></p>
                                </div>
                            </div>

                            <div class='col-12 col-md-4 col-lg-4 schol-column'>
                                <div class="schol-column">
                                    <h6><?php echo get_sub_field('deadline_title'); ?></h6>
                                    <p><?php echo get_sub_field('deadline'); ?></p>
                                </div>
                            </div>

                            <div class='col-12 col-md-4 col-lg-4 schol-column'>
                                <div class="schol-column">
                                    <h6><?php echo get_sub_field('course_title'); ?></h6>
                                    <p><?php echo get_sub_field('course'); ?></p>
                                </div>

                            </div>

                        </div>
                    </div>
                </div>

                <?php endwhile; ?>
            </div>

            <?php endif; ?>

        </section>
    </div>



</div>

<?php
get_footer();