<?php
/**
 * The template for displaying a single university post
 *
 * @package base_theme
 */

get_header();
?>
<!-- Hero Section -->
<section class="hero-section" style="background-color:<?php the_field('background_color'); ?>">
    <div class="row g-0">
        <div class="col-12 col-md-5 col-lg-5 left">
            <div class="hero-text">
                <h1 data-aos="fade-zoom-in" data-aos-duration="800">
                    UNIVERSITY REPRESENTATIONS
                </h1>
                <p data-aos="fade-zoom-in" data-aos-duration="1000">
                    Begin a journey of excellence with leading universities in Australia, Canada, the UK, and New
                    Zealand. Our expert team is here to guide you every step of the way.
                </p>

                <a href="<?php echo get_permalink(get_page_by_title('Contact Us')); ?>"> <img data-aos="fade-zoom-in"
                        data-aos-duration="1200" class="btn-image img-fluid" width="130" height="100%"
                        src="<?php echo get_home_url() ?>/wp-content/uploads/2024/04/button-image.png"
                        alt="<?php echo esc_attr($image['title']); ?>" loading="lazy" decoding="async" role="img"
                        aria-label="image">
                </a>
            </div>
        </div>
        <div class="col-12 col-md-7 col-lg-7 right">
            <img data-aos="fade-zoom-in" data-aos-duration="1200" class="btn-image img-fluid"
                src="<?php echo get_home_url() ?>//wp-content/uploads/2024/03/Artboard-6.png"
                alt="<?php echo esc_attr($image['title']); ?>" loading="lazy" decoding="async" role="img"
                aria-label="image">
        </div>
    </div>
</section>

<div class="container">


    <!-- page navigation section -->
    <section class="location-section">
        <div class="locat">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#195d9a">
                <path
                    d="M20 20C20 20.5523 19.5523 21 19 21H5C4.44772 21 4 20.5523 4 20V11L1 11L11.3273 1.6115C11.7087 1.26475 12.2913 1.26475 12.6727 1.6115L23 11L20 11V20ZM11 13V19H13V13H11Z">
                </path>
            </svg>
            <p class="page-name1">
                Home
            </p>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                <path
                    d="M13.1717 12.0007L8.22192 7.05093L9.63614 5.63672L16.0001 12.0007L9.63614 18.3646L8.22192 16.9504L13.1717 12.0007Z">
                </path>
            </svg>
            <p class="page-name">
                University Representation
            </p>
        </div>
    </section>


    <!-- filter section -->
    <section class="filter">
        <?php
        // Get all parent terms of 'country_category' taxonomy
        $parent_terms = get_terms(array(
            'taxonomy' => 'country_category',
            'parent' => 0, // Get only parent terms
        ));

        if (!empty($parent_terms)) {
            echo '<select id="urlDropdown" onchange="redirectToURL()">';
            // Add a placeholder option
            echo '<option value="" disabled selected>Select Country</option>';

            foreach ($parent_terms as $parent_term) {
                // Get permalink for parent term
                $parent_permalink = get_term_link($parent_term);

                // Output parent term as option
                ?>
            <option value="<?php echo $parent_permalink; ?>">
                <a href="<?php echo $parent_permalink; ?>"><?php echo $parent_term->name; ?></a>
            </option>
            <?php

                // Get child terms of the current parent term
                $child_terms = get_terms(array(
                    'taxonomy' => 'country_category',
                    'parent' => $parent_term->term_id,
                    'hide_empty' => false,
                ));

                // Output child terms as sub-options
                if (!empty($child_terms)) {
                    foreach ($child_terms as $child_term) {
                        $child_permalink = get_term_link($child_term);
                        ?>
            <option value="<?php echo $child_permalink; ?>">
                &nbsp;&nbsp;&nbsp;&nbsp;<?php echo $child_term->name; ?>
            </option>
            <?php
                    }
                }
            }
            echo '</select>';
        } else {
            echo 'No parent terms found.';
        }
        ?>
    </section>


    <?php
    // Get the current term object
    $current_term = get_queried_object();

    // Check if the current term exists
    if ($current_term) {
        // Get the parent term ID
        $parent_term_id = $current_term->parent;

        // If the current term has a parent term
        if ($parent_term_id != 0) {
            // Get the parent term object
            $parent_term = get_term($parent_term_id, $current_term->taxonomy);
            ?>
            <h2 class="country-name"><?php echo $parent_term->name; ?></h2>
            <?php
        } else {
            // If the current term is a parent term, display its name
            ?>
            <h2 class="country-name"><?php echo $current_term->name; ?></h2>
            <?php
        }
    } else {
        ?>
        <p>No taxonomy found.</p>
        <?php
    }
    ?>




    <div class="main-content home">


        <?php
    if (have_posts()) :
             
        while (have_posts()) : the_post();
            ?>
        <section class="university-section">



            <div class="logo-container" <?php if (empty(get_field('type_logo'))) echo ' style="display: none;"'; ?>>
                <img class="type-logo" src="<?php echo esc_url(get_field('type_logo')); ?>" alt="">
            </div>

            <h2><?php echo nl2br(esc_html(get_field('type'))); ?></h2>

            <?php if (have_rows('university_repeater')) : ?>
            <div class="row">
                <?php while (have_rows('university_repeater')) : the_row(); ?>
                <div class="col-12 col-md-4 col-lg-4">
                    <div class="card-wrap">
                        <div class="universiity-logo">
                            <?php
                                        $image = get_sub_field('logo');
                                        if (!empty($image)) :
                                            ?>
                            <img class="bg-image img-fluid" height="150px" width="150px"
                                src="<?php echo esc_url($image['url']); ?>"
                                alt="<?php echo esc_attr($image['title']); ?>" loading="lazy" decoding="async"
                                role="img" aria-label="image">
                            <?php endif; ?>
                        </div>
                        <p><?php echo get_sub_field('description'); ?></p>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
            <?php endif; ?>
        </section>
        <?php
        endwhile;
    else :
        ?>
        <p class="text-center"><?php _e('Sorry, there are no posts.'); ?></p>
        <?php
    endif;
    ?>
    </div>



</div>

<?php
get_footer();