<?php
/**
 * base_theme functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package base_theme
 */

if ( ! defined( '_S_VERSION' ) ) {
	// Replace the version number of the theme on each release.
	define( '_S_VERSION', '1.0.0' );
}


/**
 * Include Enqueue.
 */
require get_template_directory() . '/inc/enqueue.php'; //Enqueue scripts and styles.

/**
 * Include Widgets.
 */
require get_template_directory() . '/inc/widgets.php'; //Register widget area.

/**
 * Include Shortcode
 */
require get_template_directory() . '/inc/shortcode.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}



/**
 * Enqueue scripts and localize admin URL
 */
function enqueue_scripts() {
    wp_enqueue_script('jquery');
    wp_enqueue_script('your-script', get_template_directory_uri() . '/js/theme.js', array('jquery'), '1.0', true);

    // Localize the admin URL for the JavaScript file
    $admin_url = admin_url('admin-ajax.php');
    wp_localize_script('your-script', 'ajaxObject', array('admin_url' => $admin_url));
}
add_action('wp_enqueue_scripts', 'enqueue_scripts');

/**
 * Function to fetch and display all posts
 */
function display_all_posts()
{
    $args = array(
        'post_type'      => 'universitiy', // post type name
        'posts_per_page' => -1,
        'orderby'        => 'title', // Order by post title (type name)
        'order'          => 'DESC', // Order in descending order
    );
    $posts = new WP_Query($args);
    $output = '';
    if ($posts->have_posts()) {
        $countries = array();
        while ($posts->have_posts()) {
            $posts->the_post();
            $country_terms = get_the_terms($posts->post->ID, 'country_category');
            if ($country_terms && !is_wp_error($country_terms)) {
                foreach ($country_terms as $term) {
                    $term_id          = $term->term_id;
                    $term_parent_id   = $term->parent;
                    if ($term_parent_id == 0) { // Check if term is root level parent
                        $post_output = '';
                        $post_output .= '<section class="university-section">';
                        $post_output .= '<div class="logo-container">';
                        $post_output .= '<img class="type-logo" width="200px" src="' . esc_url(get_field('type_logo')) . '" alt="">';
                        $post_output .= '</div>';
                        $post_output .= '<h2>' . nl2br(esc_html(get_field('type'))) . '</h2>';
                        if (have_rows('university_repeater')) :
                            $post_output .= '<div class="row">';
                            while (have_rows('university_repeater')) : the_row();
                                $post_output .= '<div class="col-12 col-md-4 col-lg-4">';
                                $post_output .= '<div class="card-wrap">';
                                $post_output .= '<div class="university-logo">';
                                $image = get_sub_field('logo');
                                if (!empty($image)) :
                                    $post_output .= '<img class="bg-image img-fluid" height="150px" width="150px" src="' . esc_url($image['url']) . '" alt="' . esc_attr($image['title']) . '" loading="lazy" decoding="async" role="img" aria-label="image">';
                                endif;
                                $post_output .= '</div>';
                                $post_output .= '<p>' . get_sub_field('description') . '</p>';
                                $post_output .= '</div>';
                                $post_output .= '</div>';
                            endwhile;
                            $post_output .= '</div>';
                        endif;
                        $post_output .= '</section>';
                        if (!isset($countries[$term_id])) {
                            $countries[$term_id] = array(
                                'name'  => $term->name,
                                'posts' => array(),
                            );
                        }
                        $countries[$term_id]['posts'][] = $post_output;
                        break; // Stop processing other terms once the root level parent is found
                    }
                }
            }
        }
        // Sort countries in ascending order
        ksort($countries);
        foreach ($countries as $term_id => $country) {
            echo '<h2>' . $country['name'] . '</h2>';
            foreach ($country['posts'] as $post) {
                echo $post;
            }
        }
    } else {
        $output = '<p>No posts found.</p>';
    }
    wp_reset_postdata();
}



/**
 * Ajax handler to fetch universities based on selected country
 */
function get_universities_ajax_handler() {
    $country_id = isset($_POST['country_id']) ? intval($_POST['country_id']) : 0;
    if ($country_id > 0) {
        $universities = get_terms(array(
            'taxonomy' => 'country_category', // taxonomy name
            'parent' => $country_id,
            'hide_empty' => false,
        ));
        $output = '<option value="">Select University</option>';
        foreach ($universities as $university) {
            $output .= '<option value="' . $university->term_id . '">' . $university->name . '</option>';
        }
    } else {
        $output = '<option value="">Select University Type</option>';
    }
    echo $output;
    wp_die();
}
add_action('wp_ajax_get_universities', 'get_universities_ajax_handler');
add_action('wp_ajax_nopriv_get_universities', 'get_universities_ajax_handler');

/**
 * Ajax handler to fetch posts based on selected country and university
 */
function get_posts_ajax_handler() {
    $country_id = isset($_POST['country_id']) ? intval($_POST['country_id']) : 0;
    $university_id = isset($_POST['university_id']) ? intval($_POST['university_id']) : 0;

    $output = '';

    if ($country_id > 0) {
        $args = array(
            'post_type' => 'universitiy', // post type name
            'posts_per_page' => -1,
            'orderby' => 'title', // Order by post title (type name)
            'order' => 'DESC', // Order in descending order
            'tax_query' => array(
                array(
                    'taxonomy' => 'country_category', // Taxonomy for countries
                    'field' => 'term_id',
                    'terms' => $country_id,
                ),
            ),
        );

        if ($university_id > 0) {
            $args['tax_query'][] = array(
                'taxonomy' => 'country_category', // Same taxonomy, since universities are child terms
                'field' => 'term_id',
                'terms' => $university_id,
                'include_children' => false, // Set this to true if you want to include child terms as well
            );
        }

        $posts = new WP_Query($args);
        if ($posts->have_posts()) {
            $output .= '<h2>' . $country_name = get_term_field('name', $country_id, 'country_category') . '</h2>';
            while ($posts->have_posts()) {
                $posts->the_post();
               
                $output .= '<section class="university-section">';
                $output .= '<div class="logo-container">';
                $output .= '<img class="type-logo" width="200px" src="' . esc_url( get_field('type_logo') ) . '" alt="">';
                $output .= '</div>';
                $output .= '<h2>' . nl2br(esc_html(get_field('type'))) . '</h2>';
                if (have_rows('university_repeater')) :
                    $output .= '<div class="row">';
                    while (have_rows('university_repeater')) : the_row();
                        $output .= '<div class="col-12 col-md-4 col-lg-4">';
                        $output .= '<div class="card-wrap">';
                        $output .= '<div class="universiity-logo">';
                        $image = get_sub_field('logo');
                        if (!empty($image)) :
                            $output .= '<img class="bg-image img-fluid" height="150px" width="150px" src="' . esc_url($image['url']) . '" alt="' . esc_attr($image['title']) . '" loading="lazy" decoding="async" role="img" aria-label="image">';
                        endif;
                        $output .= '</div>';
                        $output .= '<p>' . get_sub_field('description') . '</p>';
                        $output .= '</div>';
                        $output .= '</div>';
                    endwhile;
                    $output .= '</div>';
                endif;
                $output .= '</section>';
            }
        } else {
            $output = '<p>No posts found.</p>';
        }
    } else {
        $output = '<p>Please select a country.</p>';
    }

    echo $output;
    wp_die();
}
add_action('wp_ajax_get_posts', 'get_posts_ajax_handler');
add_action('wp_ajax_nopriv_get_posts', 'get_posts_ajax_handler');

/**
 * Refresh URL when filtering for selected filters in university filter
 */
function university_query_vars($vars) {
    $vars[] = 'country_taxonomy';
    $vars[] = 'country_term';
    $vars[] = 'university_type';
    return $vars;
}
add_filter('query_vars', 'university_query_vars');